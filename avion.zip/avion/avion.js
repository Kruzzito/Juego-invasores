const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const scoreDisplay = document.getElementById('score');
const livesDisplay = document.getElementById('lives');
const startScreen = document.getElementById('startScreen');
const startButton = document.getElementById('startButton');
const restartButton = document.getElementById('restartButton');

const shootSound = new Audio('https://www.soundjay.com/button/beep-07.wav');
const levelUpSound = new Audio('https://www.soundjay.com/button/beep-09.wav');

const playerImage = new Image();
playerImage.src = 'https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEiMLIXZ3J31f3FGioam1wn9pkNjIw6GFDeJk1CREvr_MG6Qjers2cRtzrHVvZ_S4pEueCVtB1uMtjkyQlw0ri5GTyWqmibL4oMndm-x1Jw1DM-HdJGQ5EJxKaC1izfCF7OOYt5kxgiC4QeDmZPivTJg9tTEO81VAjYt4lJgpPuscHqsPfz5NJ_n8dBEfoM/w400-h400/juegonave.png'; 
const enemyImage = new Image();
enemyImage.src = 'https://blogger.googleusercontent.com/img/b/R29vZ2xl/AVvXsEiQBl9ttMJFsLL4Yl47jA9NTVslapZznYjq96IiUh0AQdePEi06AmMiJau71NgD_182YdELp0-RGSxTfGaVjbF1dhp-5ChP8mItwJDoLROL6f8rKgh_VBEu2FtmqDXS64QaMquZq-aqy28JvJHZB85_cL0n3VePXhhN5OXsX_v8rWSPry_2FsSYElmEkOQ/w400-h400/juegonaveenemy.png'; 

let playerX = canvas.width / 2 - 15;
let bullets = [];
let enemies = [];
let enemyBullets = [];
let score = 0;
let lives = 3;
let gameOver = false;
let level = 1;
let enemySpeed = 1;
let spawnRate = 0.01;
let totalEnemies = 3; // Inicialmente, pocos enemigos

// Dibujar jugador
function drawPlayer() {
  ctx.drawImage(playerImage, playerX, canvas.height - 50, 30, 30);
}

// Dibujar balas del jugador
function drawBullets() {
  ctx.fillStyle = "yellow";
  bullets.forEach(bullet => {
    ctx.fillRect(bullet.x, bullet.y, 5, 10);
  });
}

// Dibujar balas de enemigos
function drawEnemyBullets() {
  ctx.fillStyle = "red";
  enemyBullets.forEach(bullet => {
    ctx.fillRect(bullet.x, bullet.y, 5, 10);
  });
}

// Dibujar enemigos
function drawEnemies() {
  enemies.forEach(enemy => {
    ctx.drawImage(enemyImage, enemy.x, enemy.y, 20, 20);
  });
}

// Generar enemigos
function spawnEnemies() {
  if (enemies.length < totalEnemies && Math.random() < spawnRate) {
    const x = Math.random() * (canvas.width - 20);
    enemies.push({ x, y: 0 });
  }
}

// Los enemigos disparan
function enemyShoot() {
  enemies.forEach(enemy => {
    if (Math.random() < 0.01) {
      enemyBullets.push({ x: enemy.x + 15, y: enemy.y + 30 });
    }
  });
}

// Mover enemigos
function moveEnemies() {
  enemies = enemies.filter(enemy => enemy.y < canvas.height);
  enemies.forEach(enemy => enemy.y += enemySpeed);
}

// Mover balas del jugador
function moveBullets() {
  bullets = bullets.filter(bullet => bullet.y > 0);
  bullets.forEach(bullet => bullet.y -= 5);
}

// Mover balas enemigas
function moveEnemyBullets() {
  enemyBullets = enemyBullets.filter(bullet => bullet.y < canvas.height);
  enemyBullets.forEach(bullet => bullet.y += 3);
}

// Detectar colisiones
function detectCollisions() {
  bullets.forEach((bullet, bulletIndex) => {
    enemies.forEach((enemy, enemyIndex) => {
      const distance = Math.hypot(bullet.x - (enemy.x + 15), bullet.y - (enemy.y + 15));
      if (distance < 15) {
        bullets.splice(bulletIndex, 1);
        enemies.splice(enemyIndex, 1);
        score += 100;
        scoreDisplay.textContent = `Score: ${score}`;
      }
    });
  });

  detectPlayerCollisions();
}

// Detectar colisiones con el jugador
function detectPlayerCollisions() {
  enemyBullets.forEach((bullet, bulletIndex) => {
    const distance = Math.hypot(playerX + 15 - bullet.x, canvas.height - 35 - bullet.y);
    if (distance < 15) {
      enemyBullets.splice(bulletIndex, 1);
      lives--;
      livesDisplay.textContent = `Vidas: ${lives}`;
      if (lives <= 0) {
        gameOver = true;
      }
    }
  });
}

// Dibujar
function draw() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  drawPlayer();
  drawBullets();
  drawEnemyBullets();
  drawEnemies();
}

// Lógica del juego
function gameLoop() {
  if (gameOver) {
    endGame();
    return;
  }

  draw();
  moveBullets();
  moveEnemies();
  moveEnemyBullets();
  spawnEnemies();
  enemyShoot();
  detectCollisions();

  if (score >= level * 500) {  // Aumenta enemigos cada 500 puntos
    level++;
    totalEnemies = Math.ceil(totalEnemies * 1.1); // Aumenta en un 10% el número de enemigos
    enemySpeed += 0.5;
    spawnRate += 0.01;
    levelUpSound.play();
  }

  requestAnimationFrame(gameLoop);
}

function endGame() {
  ctx.clearRect(0, 0, canvas.width, canvas.height);
  ctx.font = "30px Arial";
  ctx.fillText("Game Over", canvas.width / 2 - 75, canvas.height / 2);
  restartButton.style.display = "block";
}

function resetGame() {
  playerX = canvas.width / 2 - 15;
  bullets = [];
  enemies = [];
  enemyBullets = [];
  score = 0;
  level = 1;
  totalEnemies = 3;
  lives = 3;
  enemySpeed = 1;
  spawnRate = 0.01;
  gameOver = false;
  scoreDisplay.textContent = `Score: 0`;
  livesDisplay.textContent = `Vidas: ${lives}`;
  restartButton.style.display = "none";
  gameLoop();
}

startButton.addEventListener('click', () => {
  startScreen.style.display = "none";
  scoreDisplay.style.display = "block";
  startButton.style.display = "none";
  livesDisplay.style.display = "block";
  livesDisplay.textContent = `Vidas: ${lives}`;
  gameLoop();
});

restartButton.addEventListener('click', resetGame);

document.addEventListener('keydown', e => {
  if (e.key === "ArrowLeft" && playerX > 0) playerX -= 10;
  else if (e.key === "ArrowRight" && playerX < canvas.width - 30) playerX += 10;
  else if ((e.key === "a" || e.key === "A") && !gameOver) {
    bullets.push({ x: playerX + 12, y: canvas.height - 60 });
    shootSound.play();
  }
});

// Detectar el movimiento del dispositivo
function handleOrientation(event) {
  const gamma = event.gamma; // Inclinación horizontal del dispositivo
  const sensitivity = 5; // Sensibilidad ajustable

  // Suavizar el movimiento del jugador en móviles
  if (gamma < -5 && playerX > 0) {
    playerX -= Math.abs(gamma / sensitivity);
  } else if (gamma > 5 && playerX < canvas.width - 30) {
    playerX += Math.abs(gamma / sensitivity);
  }
}

// Detectar toque en la pantalla para disparar
function handleTouchStart(event) {
  const touch = event.touches[0];
  if (!gameOver) {
    bullets.push({ x: playerX + 12, y: canvas.height - 60 });
    shootSound.play();
  }
}

// Detectar el movimiento del dispositivo en dispositivos móviles
window.addEventListener('deviceorientation', handleOrientation);

// Disparar al tocar la pantalla
canvas.addEventListener('touchstart', handleTouchStart);